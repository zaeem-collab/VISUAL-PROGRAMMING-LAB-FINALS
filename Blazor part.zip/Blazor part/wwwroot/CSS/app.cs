﻿/* wwwroot/css/app.css */


.product - card {
border: 1px solid #ccc;
    padding: 10px;
margin: 10px;
    border - radius: 5px;
width: 200px;
    background - color: #f9f9f9;
    box - shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
}


.product - list {
display: flex;
    flex - wrap: wrap;
gap: 20px;
    margin - top: 20px;
}
