using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container
builder.Services.AddRazorPages();
builder.Services.AddServerSideBlazor(); // Add Blazor Server support

var app = builder.Build();

// Configure the HTTP request pipeline
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error"); // Configure global error handler
    app.UseHsts(); // Use HTTP Strict Transport Security for production
}

app.UseHttpsRedirection(); // Redirect HTTP to HTTPS
app.UseStaticFiles(); // Serve static files from the "wwwroot" folder

app.UseRouting(); // Enable routing for the app

// Map Blazor and fallback
app.MapBlazorHub(); // Maps the SignalR hub for Blazor Server
app.MapFallbackToPage("/_Host"); // Fallback to the _Host.cshtml page

app.Run(); // Start the application

// Product model class
public class Product
{
    public string Name { get; set; } // Product name
    public string Category { get; set; } // Product category
    public decimal Price { get; set; } // Product price
}
